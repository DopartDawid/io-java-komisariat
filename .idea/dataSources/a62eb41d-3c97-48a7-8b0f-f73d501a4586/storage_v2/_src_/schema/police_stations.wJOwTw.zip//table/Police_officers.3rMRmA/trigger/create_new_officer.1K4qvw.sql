create definer = root@localhost trigger create_new_officer
    before insert
    on Police_officers
    for each row
BEGIN
    INSERT INTO Users (Login, Pass_Hash, Access_level) VALUES (CONCAT(NEW.First_Name, "_", NEW.Second_Name), "", 'Officer');
    SET NEW.User_ID = (SELECT u.ID FROM Users u WHERE u.Login = CONCAT(NEW.First_Name, "_", NEW.Second_Name));
END;

