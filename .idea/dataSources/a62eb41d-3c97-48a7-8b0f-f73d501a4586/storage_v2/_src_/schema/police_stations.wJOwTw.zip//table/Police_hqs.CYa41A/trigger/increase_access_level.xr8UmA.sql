create definer = root@localhost trigger increase_access_level
    after UPDATE
    on Police_hqs
    for each row
    UPDATE Users u SET u.Access_level = 'Commissioner' WHERE u.ID = (SELECT p.User_ID FROM Police_officers p WHERE p.Badge_Number = NEW.Commissioner_ID);

