create definer = root@localhost trigger delete_commissioner
    before DELETE
    on Police_officers
    for each row
BEGIN
    IF OLD.Badge_Number = ANY (SELECT Commissioner_ID FROM Police_hqs) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Przed usunieciem komendanta, przypisz nowego do jego komendy!";
    END IF;
END;

